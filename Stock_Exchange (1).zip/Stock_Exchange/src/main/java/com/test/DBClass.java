package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBClass
{
	public Connection cn;
	
	public void connect() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/stocks","root","yamunabv@21081999");
		
	}
	public void close() throws Exception{
		cn.close();
	}
	public int execute(String sql,Object ...args) throws Exception
	{
		connect();
		PreparedStatement ps=cn.prepareStatement(sql);
		for(int i=0;i<args.length;i++) {
			ps.setObject(i+1,args[i]);
		}
		int k=ps.executeUpdate();
		close();
		return k;
	}
	public ResultSet getData(String sql,Object ...args) throws Exception
	{
		connect();
		PreparedStatement ps=cn.prepareStatement(sql);
		for(int i=0;i<args.length;i++) {
			ps.setObject(i+1,args[i]);
		}
		ResultSet rs=ps.executeQuery();
		//close();
		return rs;
	}

}
