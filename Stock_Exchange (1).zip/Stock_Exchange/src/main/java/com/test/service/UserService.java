package com.test.service;

import com.test.DBClass;
import com.test.model.User;


public class UserService
{
	public void signup(User user)
	{
		DBClass db=new DBClass();
		
		try
		{
			db.execute("insert into UserReg(username, phone, email, password, secq, seca) values(?,?,?,?,?,?)", user.getUsername(),user.getPhone(),user.getEmail(),user.getPassword(),user.getSecq(),user.getSeca());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
