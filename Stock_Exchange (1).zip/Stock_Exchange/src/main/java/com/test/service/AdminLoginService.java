package com.test.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.DBClass;
import com.test.model.AdminLogin;

public class AdminLoginService
{
	public boolean login(AdminLogin login) throws SQLException{
		
		DBClass db = new DBClass();
		ResultSet rs=null;
		try {
			rs = db.getData("select * from adminlogin where userid=? and password=?", login.getUsername(),login.getPassword());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		if(rs.next()) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean ChangePass(AdminLogin admin)
	{
		DBClass db = new DBClass();
		try {
			db.execute("update adminlogin set password=? where userid=?",admin.getPassword(),admin.getUsername());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return true;
	}

}
