package com.test1;

public class payment
{
		private String owner_name;
		private String cvv;
		private String cardnumber;



		public String getOwner_name() {
		return owner_name;
		}
		public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
		}
		public String getCvv() {
		return cvv;
		}
		public void setCvv(String cvv) {
		this.cvv = cvv;
		}
		public String getCardnumber() {
		return cardnumber;
		}
		public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
		}



}
