package com.test1;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/paycheck")
public class paycheck
{
	private static final long serialVersionUID = 1L;



	/**
	* @see HttpServlet#HttpServlet()
	*/
	public paycheck() {



	super();
	// TODO Auto-generated constructor stub
	}





	/**
	* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	*/
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	response.getWriter().append("Served at: ").append(request.getContextPath());
	}





	/**
	* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	*/
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {



	String owner_name=request.getParameter("owner_name");
	String cvv=request.getParameter("cvv");
	String cardnumber=request.getParameter("cardnumber");
	String expiry=request.getParameter("expiry");
	if(owner_name.equals("yamuna")&&cvv.equals("123")&&cardnumber.equals("547380320415")&&expiry.equals("may 2023"))
	{
	response.sendRedirect("win.jsp");
	}
	else
	{
	response.sendRedirect("error1.jsp");
	}



	}



}
